# Open Source Release Gate — GenLayer Intelligent Contract

## Purpose
Open Source Release Gate is a reusable evidence-review primitive for open-source
maintainers, grant reviewers, and project teams. A submitter supplies a public
release/evidence page plus explicit acceptance criteria. The contract evaluates
whether the page contains evidence for those criteria and stores the result
only after GenLayer's equivalence/consensus mechanism accepts it.

## Why GenLayer is useful here
Release readiness is not always reducible to one deterministic check. Evidence
may include release notes, linked documentation, test reports, and implementation
details. This contract combines:
- deterministic input validation and unique review IDs;
- live retrieval of public evidence;
- structured assessment with explicit criteria and limitations;
- comparative Equivalence Principle validation, where validators independently
  retrieve the same page and compare decision-bearing fields;
- persistent review records and read methods.

## Important limitations
- This is a prototype, not an audited production contract.
- It reviews only the supplied public page (up to 12,000 characters) and does
  not recursively inspect linked repositories or execute tests.
- A "pass" is an evidence-based review result, not a security guarantee.
- Public pages may change or be unavailable. Review results reflect the evidence
  seen at execution time.
- Test this in GenLayer Studio and run the current GenVM linter before submitting
  or deploying. Do not claim it has been tested or deployed until you actually do so.

## Files
- `open_source_release_gate.py`: contract source
- `submission_description.md`: suggested description for the Portal
- `test_plan.md`: manual test plan

## Quick Studio test plan
1. Open GenLayer Studio and create a new Intelligent Contract.
2. Paste `open_source_release_gate.py` into the editor.
3. Run the current Studio compile/lint workflow. Fix any SDK-version errors before
   proceeding; APIs can change between protocol versions.
4. Deploy to the supported development network.
5. Call `review_release` with:
   - `review_id`: `release-demo-001`
   - `project_name`: a real open-source project
   - `evidence_url`: an HTTPS release page or public documentation page
   - `acceptance_criteria`: e.g. `Release notes are present; setup instructions
     are documented; test evidence is linked; known limitations are stated.`
6. Read `get_review("release-demo-001")` and `get_stats()`.
7. Test failure paths: duplicate ID, non-HTTPS URL, missing criteria, and a page
   that does not provide enough evidence.
8. Save the contract address, transaction link, source, and test evidence only
   after successful testing.

## References
- GenLayer Intelligent Contracts:
  https://docs.genlayer.com/developers/intelligent-contracts/introduction
- Equivalence Principle:
  https://docs.genlayer.com/developers/intelligent-contracts/equivalence-principle
- Non-determinism:
  https://docs.genlayer.com/developers/intelligent-contracts/features/non-determinism
