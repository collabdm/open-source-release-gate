# Manual Test Plan

## Positive case
Use a public release page that visibly contains release notes, documentation, and test evidence. Supply criteria that are directly evidenced. Expected: a structured report with per-criterion statuses and a reasoned decision.

## Insufficient evidence
Use a simple homepage with no release notes or test information. Expected: `insufficient_evidence` or `needs_work`, not `pass`.

## Input validation
- Empty or overlong review ID → rejected.
- Duplicate review ID → rejected.
- URL that does not start with `https://` → rejected.
- Empty acceptance criteria → rejected.

## State
After a successful consensus transaction:
- `get_review(review_id)` returns the stored report.
- `get_stats()` increments `review_count` and updates `latest_review_id`.

## Consensus
Inspect the transaction trace/logs in Studio and verify that comparative validation ran. If the SDK/API has changed or a test fails, fix and rerun before submission.
