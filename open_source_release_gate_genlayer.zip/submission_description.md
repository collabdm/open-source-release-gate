# Open Source Release Gate

**Category:** Builder → Intelligent Contracts

**Short description**
A reusable GenLayer contract primitive for evidence-based open-source release reviews. It compares a project's public release evidence against explicit acceptance criteria and records a structured review only after validators independently assess the evidence and reach consensus.

**Problem**
Project milestone reviews often depend on scattered release notes, documentation, test reports, and other public evidence. A reviewer needs to distinguish a supported criterion from a claim that is missing or unclear, without trusting one model's answer.

**What this contract does**
- Accepts a unique review ID, project name, HTTPS evidence URL, and explicit acceptance criteria.
- Fetches public evidence and asks for a structured report: decision, criterion-by-criterion checks, strengths, gaps, summary, and limitations.
- Uses comparative Equivalence Principle validation so validators independently retrieve the evidence and compare the decision and material criterion statuses.
- Stores a report by review ID only after consensus succeeds.
- Exposes read methods for individual reports and aggregate review statistics.

**Consensus design**
The leader and validators independently fetch the supplied page and perform the same structured assessment. The equivalence principle requires agreement on the decision and material criterion statuses while allowing harmless wording differences. Missing or inaccessible evidence must not be treated as a pass.

**State design**
- `reviews`: mapping of unique review IDs to consensus-accepted reports.
- `review_count`: count of accepted review transactions.
- `latest_review_id`: most recently recorded review ID.

**Limitations**
This prototype evaluates only the supplied public page and does not execute code, recursively inspect links, or replace a professional security audit. A `pass` means the submitted page appears to support the stated criteria, not that the software is guaranteed safe or correct.

**Evidence to attach**
After actually testing, attach the contract source, Studio compile/test evidence, a successful transaction link, a readback of the saved report, and at least one negative test showing insufficient evidence is not marked as pass. Do not claim deployment or tests unless completed.
